# Firebase Office Data App (Single Page) — GitHub Pages ready

## What this is
A single HTML page that uses **Firebase Firestore** as backend to store office entries:
- Fields: **Name**, **Phone**, **Address**, **Amount** (number)
- Search by name (real-time like)
- Export CSV (client-side)
- Works when hosted on **GitHub Pages** or any static host

## Setup steps (quick)
1. Create a Firebase project at https://console.firebase.google.com/
2. In Firebase console, go to **Firestore Database** → Create database → Start in test mode (for initial setup).
3. In Project settings → SDK setup and config → copy the Firebase config object.
4. Open `index.html` and paste your config into the `initFirebase()` function (replace the placeholders).
5. Commit & push the files to a GitHub repo, enable GitHub Pages (branch: main, root folder).
6. Visit the GitHub Pages URL and test.

## Firestore rules (for testing)
Open Firestore rules and set temporary rules while testing:
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if true;
    }
  }
}
```
**Important:** This is insecure for production. After setup, restrict rules or add authentication.

## Notes
- This app uses client-side Firestore. For production, add security rules & optionally implement Firebase Authentication.
- If you expect many records, consider adding paging or server-side export.
